Contributors to these tutorials include Jane Herriman, Andreas Noack, Sacha Verweij, and Alan Edelman
