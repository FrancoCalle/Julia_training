These materials are based on those in the "intro-to-julia" directory and were translated by Miguel Raz Guzmán Macedo.


