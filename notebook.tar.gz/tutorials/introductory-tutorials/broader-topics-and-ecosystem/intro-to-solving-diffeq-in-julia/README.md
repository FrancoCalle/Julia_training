These materials were created by Chris Rackauckas.
