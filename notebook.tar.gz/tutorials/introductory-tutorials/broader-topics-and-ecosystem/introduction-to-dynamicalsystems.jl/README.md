# tutorials
Jupyter notebooks and markdownfiles that serve as tutorials for the packages of JuliaDynamics

These materials were created by George Datseris.
