WARNING: THIS IS AN EPHEMERAL DISK.

Any data stored in this folder is SUBJECT TO LOSS and THERE IS NO WAY TO
RECOVER IT.

Please do not use this folder for storing any data.

